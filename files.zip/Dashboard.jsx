/**
 * pages/Dashboard.jsx
 * ─────────────────────────────────────────────────────────────
 * Overview dashboard.
 *
 * API calls in this file (via useAnalytics hook):
 *   GET /api/analytics/kpis    → KPI cards
 *   GET /api/analytics         → pie chart, trend chart, yield chart
 *   GET /api/alerts            → alert feed
 */
import {
  AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell,
  ResponsiveContainer, Tooltip, XAxis, YAxis, CartesianGrid,
} from "recharts";
import { useAnalytics } from "../hooks/useAnalytics";
import { Card, SectionTitle, KpiCard, Badge } from "../components/ui";
import { PageContainer } from "../components/layout";
import { WaferMap } from "../components/wafer";
import { C } from "../utils/constants";

// ── Skeleton placeholder while data loads ─────────────────────
function Skeleton({ height = 200 }) {
  return (
    <div style={{ height, background: `linear-gradient(90deg, ${C.panelAlt} 25%, ${C.border} 50%, ${C.panelAlt} 75%)`, borderRadius: 8, animation: "pulse 1.5s infinite" }} />
  );
}

const TOOLTIP_STYLE = { background: C.panel, border: `1px solid ${C.border}`, borderRadius: 8, color: C.text, fontSize: 12 };

export default function Dashboard() {
  // ── useAnalytics fetches all dashboard data from the API ───
  const { kpis, analytics, alerts, loading, error, refresh, dismiss } = useAnalytics({
    refreshInterval: 60_000, // re-poll every 60 s
  });

  if (error) {
    return (
      <PageContainer title="Dashboard">
        <div style={{ color: C.red, padding: 20 }}>
          ▲ Failed to load dashboard data: {error}
          <button onClick={refresh} style={{ marginLeft: 12 }}>Retry</button>
        </div>
      </PageContainer>
    );
  }

  return (
    <PageContainer
      title="Dashboard"
      subtitle={`${new Date().toLocaleString()} · Fab-3 Line A`}
    >
      <div style={{ display: "grid", gap: 16 }}>

        {/* ── KPI Row
            Data source: GET /api/analytics/kpis
            Fields: total_wafers, defect_rate, mfg_yield, active_alerts  */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 12 }}>
          {loading || !kpis ? (
            Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} height={90} />)
          ) : (
            <>
              <KpiCard label="Wafers Analyzed" value={kpis.total_wafers?.toLocaleString()} delta="↑ 3.2% today" color="green" icon="⬡" />
              <KpiCard label="Defect Rate"      value={kpis.defect_rate?.toFixed(1)} unit="%" delta={`${kpis.delta_defect_rate > 0 ? "↑" : "↓"} ${Math.abs(kpis.delta_defect_rate).toFixed(1)}% vs yesterday`} color="amber" icon="◉" />
              <KpiCard label="Mfg Yield"        value={kpis.mfg_yield?.toFixed(1)} unit="%" delta={`${kpis.delta_yield > 0 ? "↑" : "↓"} ${Math.abs(kpis.delta_yield).toFixed(1)}% this week`} color="blue" icon="◈" />
              <KpiCard label="Active Alerts"    value={kpis.active_alerts} delta={`${alerts.filter(a => a.type === "critical").length} critical`} color="red" icon="△" />
            </>
          )}
        </div>

        {/* ── Charts Row 1
            Data source: GET /api/analytics
            Fields: defect_distribution, trend  */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1.6fr", gap: 12 }}>
          <Card>
            <SectionTitle>Defect Type Distribution</SectionTitle>
            {loading || !analytics ? <Skeleton /> : (
              <>
                <ResponsiveContainer width="100%" height={200}>
                  <PieChart>
                    <Pie data={analytics.defect_distribution} dataKey="value" cx="50%" cy="50%" innerRadius={50} outerRadius={85} paddingAngle={3}>
                      {analytics.defect_distribution.map((d, i) => <Cell key={i} fill={d.color} />)}
                    </Pie>
                    <Tooltip contentStyle={TOOLTIP_STYLE} />
                  </PieChart>
                </ResponsiveContainer>
                <div style={{ display: "flex", flexWrap: "wrap", gap: 8, justifyContent: "center", marginTop: 4 }}>
                  {analytics.defect_distribution.map((d) => (
                    <div key={d.name} style={{ display: "flex", alignItems: "center", gap: 5, fontSize: 11, color: C.textMid }}>
                      <span style={{ width: 8, height: 8, borderRadius: 2, background: d.color, display: "block" }} />
                      {d.name}
                    </div>
                  ))}
                </div>
              </>
            )}
          </Card>

          <Card>
            <SectionTitle>7-Day Defect Trend</SectionTitle>
            {loading || !analytics ? <Skeleton height={220} /> : (
              <ResponsiveContainer width="100%" height={220}>
                <AreaChart data={analytics.trend}>
                  <defs>
                    {[["edge", C.red], ["scratch", C.amber], ["center", C.purple]].map(([k, c]) => (
                      <linearGradient key={k} id={`g${k}`} x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor={c} stopOpacity={0.3} />
                        <stop offset="95%" stopColor={c} stopOpacity={0} />
                      </linearGradient>
                    ))}
                  </defs>
                  <CartesianGrid stroke={C.border} strokeDasharray="3 3" />
                  <XAxis dataKey="t" tick={{ fill: C.textDim, fontSize: 11 }} />
                  <YAxis tick={{ fill: C.textDim, fontSize: 11 }} />
                  <Tooltip contentStyle={TOOLTIP_STYLE} />
                  <Area type="monotone" dataKey="edge"   stroke={C.red}    fill="url(#gedge)"   strokeWidth={2} name="Edge-ring" />
                  <Area type="monotone" dataKey="scratch" stroke={C.amber}  fill="url(#gscratch)" strokeWidth={2} name="Scratch" />
                  <Area type="monotone" dataKey="center" stroke={C.purple} fill="url(#gcenter)" strokeWidth={2} name="Center" />
                </AreaChart>
              </ResponsiveContainer>
            )}
          </Card>
        </div>

        {/* ── Charts Row 2
            Data source: GET /api/analytics → yield_by_batch  */}
        <div style={{ display: "grid", gridTemplateColumns: "1.6fr 1fr", gap: 12 }}>
          <Card>
            <SectionTitle>Batch Manufacturing Yield</SectionTitle>
            {loading || !analytics ? <Skeleton height={200} /> : (
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={analytics.yield_by_batch}>
                  <CartesianGrid stroke={C.border} strokeDasharray="3 3" />
                  <XAxis dataKey="batch" tick={{ fill: C.textDim, fontSize: 10 }} />
                  <YAxis domain={[50, 100]} tick={{ fill: C.textDim, fontSize: 11 }} />
                  <Tooltip contentStyle={TOOLTIP_STYLE} />
                  <Bar dataKey="yield" name="Yield %" radius={[4, 4, 0, 0]}>
                    {analytics.yield_by_batch.map((d, i) => (
                      <Cell key={i} fill={d.yield >= 80 ? C.green : d.yield >= 70 ? C.amber : C.red} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            )}
          </Card>

          <Card>
            <SectionTitle>Latest Wafer</SectionTitle>
            <div style={{ display: "flex", justifyContent: "center" }}>
              <WaferMap />
            </div>
          </Card>
        </div>

        {/* ── Alert feed
            Data source: GET /api/alerts
            Dismiss calls PATCH /api/alerts/:id/dismiss  */}
        <Card>
          <SectionTitle>Active Alerts</SectionTitle>
          {loading ? <Skeleton height={100} /> : (
            <div style={{ display: "grid", gridTemplateColumns: "repeat(2,1fr)", gap: 10 }}>
              {alerts.map((a) => {
                const col = a.type === "critical" ? C.red : a.type === "warning" ? C.amber : C.blue;
                return (
                  <div key={a.id} style={{ display: "flex", gap: 12, alignItems: "flex-start", background: C.panelAlt, border: `1px solid ${C.border}`, borderLeft: `3px solid ${col}`, borderRadius: 8, padding: "10px 14px" }}>
                    <div style={{ flex: 1 }}>
                      <div style={{ color: C.text, fontSize: 13 }}>{a.message ?? a.msg}</div>
                      <div style={{ color: C.textDim, fontSize: 11, marginTop: 3 }}>{a.time}</div>
                    </div>
                    <Badge color={a.type === "critical" ? "red" : a.type === "warning" ? "amber" : "blue"}>{a.type}</Badge>
                  </div>
                );
              })}
            </div>
          )}
        </Card>
      </div>
    </PageContainer>
  );
}
