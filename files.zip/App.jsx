/**
 * App.jsx
 * ─────────────────────────────────────────────────────────────
 * Root component. Owns:
 *   • Client-side "page" routing (no React Router needed for SPA)
 *   • Global layout (Header + Sidebar + PageContainer)
 *   • Shared alert count passed down to Header
 *
 * To use React Router instead, replace the `page` state +
 * NAV_ITEMS mapping with <Routes> and <Route> declarations.
 */
import { useState, lazy, Suspense } from "react";
import { Header, Sidebar } from "./components/layout";
import { useAnalytics } from "./hooks/useAnalytics";
import { C } from "./utils/constants";

// ── Lazy-load pages to keep initial bundle small ───────────────
const Dashboard       = lazy(() => import("./pages/Dashboard"));
const Upload          = lazy(() => import("./pages/Upload"));
const History         = lazy(() => import("./pages/HistoryAndModel").then(m => ({ default: m.default })));
const ModelPerformance = lazy(() => import("./pages/HistoryAndModel").then(m => ({ default: m.ModelPerformance })));

// ── Inline pages (small enough not to split) ──────────────────
// Add more here as you build them out.
function Placeholder({ title }) {
  return (
    <div style={{ padding: 40, color: C.textDim, textAlign: "center" }}>
      <div style={{ fontSize: 18, marginBottom: 8, color: C.textMid }}>{title}</div>
      <div style={{ fontSize: 13 }}>Page under construction – connect your API endpoint here</div>
    </div>
  );
}

const PAGE_MAP = {
  dashboard: Dashboard,
  upload:    Upload,
  history:   History,
  model:     ModelPerformance,
  batch:     () => <Placeholder title="Batch Analysis" />,
  analytics: () => <Placeholder title="Analytics" />,
  patterns:  () => <Placeholder title="Defect Patterns" />,
  alerts:    () => <Placeholder title="Alerts" />,
  settings:  () => <Placeholder title="Settings" />,
};

function LoadingFallback() {
  return (
    <div style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center", color: C.textDim }}>
      Loading…
    </div>
  );
}

export default function App() {
  const [page, setPage] = useState("dashboard");

  // Fetch alerts at the root level so Header can show the badge count
  // without re-fetching on every page change.
  // This uses GET /api/alerts (via useAnalytics)
  const { alerts } = useAnalytics({ refreshInterval: 30_000 });

  const PageComponent = PAGE_MAP[page] ?? Dashboard;

  return (
    <div style={{
      background: C.bg, color: C.text, minHeight: "100vh",
      fontFamily: "'DM Mono', 'Space Mono', monospace",
      display: "flex", flexDirection: "column",
    }}>
      <style>{`
        * { box-sizing: border-box; margin: 0; padding: 0; }
        ::-webkit-scrollbar { width: 6px; }
        ::-webkit-scrollbar-track { background: ${C.bg}; }
        ::-webkit-scrollbar-thumb { background: ${C.border}; border-radius: 3px; }
        @keyframes pulse  { from { opacity: 0.6; } to { opacity: 1; } }
        @keyframes blink  { 0%,100% { opacity: 1; } 50% { opacity: 0.3; } }
      `}</style>

      {/* ── Top header ─────────────────────────────────────── */}
      {/* modelVersion comes from GET /api/model-metrics (fetched in ModelPerformance page) */}
      {/* For the header we pass a static default; wire it up from a global store if needed */}
      <Header
        alertCount={alerts.filter((a) => !a.dismissed).length}
        alerts={alerts}
        modelVersion="v2.4"
        systemStatus="nominal"
      />

      <div style={{ display: "flex", flex: 1, overflow: "hidden" }}>
        {/* ── Sidebar ──────────────────────────────────────── */}
        <Sidebar activePage={page} onNavigate={setPage} gpuLoad={62} />
        {/* gpuLoad above should come from GET /api/system-health (optional endpoint) */}

        {/* ── Page area ────────────────────────────────────── */}
        <Suspense fallback={<LoadingFallback />}>
          <PageComponent />
        </Suspense>
      </div>
    </div>
  );
}
