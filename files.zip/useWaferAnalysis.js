/**
 * hooks/useWaferAnalysis.js
 * ─────────────────────────────────────────────────────────────
 * Manages the full lifecycle of a single-wafer ML inference request:
 *   idle → uploading → analyzing → done | error
 *
 * Usage:
 *   const { analyze, result, phase, progress, error, reset } = useWaferAnalysis();
 *
 *   // In your upload handler:
 *   await analyze(file);
 */
import { useState, useCallback } from "react";
import { analyzeWafer } from "../services/waferApi";

/**
 * @typedef {"idle"|"uploading"|"analyzing"|"done"|"error"} Phase
 *
 * @typedef {{
 *   wafer_id:       string,
 *   defect_type:    string,
 *   confidence:     number,
 *   severity:       "Low"|"Medium"|"High",
 *   bounding_boxes: Array<{x:number,y:number,w:number,h:number,label:string,confidence:number}>,
 *   heatmap_url:    string,
 *   processed_at:   string,
 * }} AnalysisResult
 */

export function useWaferAnalysis() {
  /** @type {[Phase, Function]} */
  const [phase, setPhase] = useState("idle");
  /** @type {[AnalysisResult|null, Function]} */
  const [result, setResult] = useState(null);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState(null);

  /**
   * analyze
   * Call this with the File object to trigger ML inference.
   *
   * Flow:
   *  1. phase → "uploading"   (file being sent to FastAPI)
   *  2. phase → "analyzing"   (backend running YOLO+CNN)
   *  3. phase → "done"        (result returned & stored)
   *     or → "error"          (network/model failure)
   */
  const analyze = useCallback(async (imageFile) => {
    if (!imageFile) return;

    setPhase("uploading");
    setProgress(0);
    setError(null);
    setResult(null);

    try {
      // ── STEP 1: POST /api/analyze-wafer ──────────────────────
      // The backend will:
      //   a) Receive the multipart image
      //   b) Run pre-processing (resize, normalize)
      //   c) Run YOLO detection → bounding_boxes
      //   d) Run CNN classification → defect_type, confidence
      //   e) Generate Grad-CAM → heatmap_url
      //   f) Persist result to DB
      //   g) Return JSON response
      const data = await analyzeWafer(imageFile, (pct) => {
        // 0-60%  = upload progress
        setProgress(Math.round(pct * 0.6));
        if (pct === 100) setPhase("analyzing");
      });

      // ── STEP 2: Simulate remaining inference time ─────────────
      // In production remove this – the API won't return until done.
      // It's here to show "Analyzing…" in the UI while awaiting response.
      setProgress(85);
      await new Promise((r) => setTimeout(r, 300)); // cosmetic delay
      setProgress(100);

      setResult(data);
      setPhase("done");
    } catch (err) {
      setError(err.message ?? "Analysis failed");
      setPhase("error");
    }
  }, []);

  const reset = useCallback(() => {
    setPhase("idle");
    setResult(null);
    setProgress(0);
    setError(null);
  }, []);

  return { analyze, result, phase, progress, error, reset };
}
