"""
backend/main.py
────────────────────────────────────────────────────────────────
FastAPI backend stub for WaferVision AI.

Every endpoint that the React frontend calls is defined here.
Replace the placeholder logic with your real YOLO / CNN model code.

Install:
  pip install fastapi uvicorn python-multipart torch torchvision
  pip install ultralytics opencv-python pillow

Run:
  uvicorn main:app --reload --port 8000
"""

from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from typing import Optional
import uuid, datetime, pathlib, shutil

app = FastAPI(title="WaferVision AI", version="2.4.0")

# ── CORS: allow the Vite dev server ──────────────────────────────
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://localhost:3000"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Serve generated heatmap PNGs
pathlib.Path("static/heatmaps").mkdir(parents=True, exist_ok=True)
app.mount("/static", StaticFiles(directory="static"), name="static")


# ════════════════════════════════════════════════════════════════
# POST /api/analyze-wafer
# Called by: pages/Upload.jsx → useWaferAnalysis → waferApi.analyzeWafer
# ════════════════════════════════════════════════════════════════
@app.post("/api/analyze-wafer")
async def analyze_wafer(file: UploadFile = File(...)):
    """
    1. Save uploaded image to disk
    2. Run YOLO inference  → bounding_boxes
    3. Run CNN classifier  → defect_type, confidence
    4. Run Grad-CAM        → heatmap PNG saved to /static/heatmaps/
    5. Persist result to DB
    6. Return JSON
    """
    wafer_id = f"WF-{uuid.uuid4().hex[:6].upper()}"

    # ── Save file ───────────────────────────────────────────────
    save_path = pathlib.Path(f"uploads/{wafer_id}_{file.filename}")
    save_path.parent.mkdir(exist_ok=True)
    with save_path.open("wb") as f:
        shutil.copyfileobj(file.file, f)

    # ── TODO: Replace stub below with real model calls ──────────
    #
    # from models.yolo_detector  import detect_defects      # → bounding_boxes
    # from models.cnn_classifier import classify_defect     # → defect_type, confidence
    # from models.gradcam        import generate_heatmap    # → saves PNG, returns URL
    #
    # bounding_boxes = detect_defects(str(save_path))
    # defect_type, confidence = classify_defect(str(save_path))
    # heatmap_url = generate_heatmap(str(save_path), wafer_id)
    # ────────────────────────────────────────────────────────────

    # Stub response – matches the TypeScript shape the frontend expects
    return {
        "wafer_id":      wafer_id,
        "defect_type":   "Edge-ring",
        "confidence":    0.91,
        "severity":      "Medium",
        "bounding_boxes": [
            {"x": 120, "y": 40,  "w": 30, "h": 30, "label": "Edge-ring", "confidence": 0.92},
            {"x": 240, "y": 35,  "w": 24, "h": 24, "label": "Edge-ring", "confidence": 0.87},
            {"x": 260, "y": 155, "w": 26, "h": 26, "label": "Scratch",   "confidence": 0.83},
        ],
        # Real path: f"/static/heatmaps/{wafer_id}.png" after Grad-CAM runs
        "heatmap_url":   f"/static/heatmaps/{wafer_id}.png",
        "processed_at":  datetime.datetime.utcnow().isoformat(),
    }


# ════════════════════════════════════════════════════════════════
# GET /api/history
# Called by: pages/History.jsx → useHistory → waferApi.fetchHistory
# ════════════════════════════════════════════════════════════════
@app.get("/api/history")
async def get_history(page: int = 1, limit: int = 20,
                      search: Optional[str] = None,
                      defect_type: Optional[str] = None):
    """
    Returns paginated inspection records from your database.
    Replace the stub list with a real DB query.
    """
    # TODO: query your DB
    # records = db.query(WaferInspection)
    # if defect_type: records = records.filter_by(defect_type=defect_type)
    # if search:      records = records.filter(WaferInspection.wafer_id.like(f"%{search}%"))
    # total = records.count()
    # items = records.offset((page-1)*limit).limit(limit).all()

    stub_items = [
        {"wafer_id": f"WF-{4890+i}", "timestamp": "2026-03-06T09:14:22", "defect_type": "Edge-ring",
         "confidence": 0.91, "severity": "Medium", "verified": True, "engineer": "E.Kim"}
        for i in range(1, limit + 1)
    ]
    return {"items": stub_items, "total": 142, "page": page, "pages": 8}


# ════════════════════════════════════════════════════════════════
# GET /api/analytics/kpis
# Called by: pages/Dashboard.jsx → useAnalytics → analyticsApi.fetchKpis
# ════════════════════════════════════════════════════════════════
@app.get("/api/analytics/kpis")
async def get_kpis():
    # TODO: aggregate from DB
    return {
        "total_wafers":      14892,
        "defect_rate":       18.4,
        "mfg_yield":         81.6,
        "active_alerts":     4,
        "delta_defect_rate": -1.1,
        "delta_yield":        2.3,
    }


# ════════════════════════════════════════════════════════════════
# GET /api/analytics
# Called by: pages/Dashboard.jsx → useAnalytics → analyticsApi.fetchAnalytics
# ════════════════════════════════════════════════════════════════
@app.get("/api/analytics")
async def get_analytics(days: int = 7):
    # TODO: aggregate from DB for last `days` days
    return {
        "defect_distribution": [
            {"name": "Edge-ring", "value": 38, "color": "#ef4444"},
            {"name": "Scratch",   "value": 27, "color": "#f59e0b"},
            {"name": "Center",    "value": 18, "color": "#a78bfa"},
            {"name": "Random",    "value": 11, "color": "#38bdf8"},
            {"name": "Clean",     "value":  6, "color": "#00ff9d"},
        ],
        "trend": [
            {"t": "Mon", "edge": 4, "scratch": 2, "center": 1},
            {"t": "Tue", "edge": 6, "scratch": 3, "center": 2},
            {"t": "Wed", "edge": 3, "scratch": 5, "center": 1},
            {"t": "Thu", "edge": 8, "scratch": 2, "center": 3},
            {"t": "Fri", "edge": 5, "scratch": 4, "center": 2},
            {"t": "Sat", "edge": 7, "scratch": 6, "center": 1},
            {"t": "Sun", "edge": 9, "scratch": 3, "center": 4},
        ],
        "yield_by_batch": [
            {"batch": "B1018", "yield": 78},
            {"batch": "B1019", "yield": 82},
            {"batch": "B1020", "yield": 71},
            {"batch": "B1021", "yield": 88},
            {"batch": "B1022", "yield": 65},
            {"batch": "B1023", "yield": 74},
            {"batch": "B1024", "yield": 69},
        ],
    }


# ════════════════════════════════════════════════════════════════
# GET /api/alerts
# Called by: Header.jsx + pages/Dashboard.jsx → useAnalytics
# ════════════════════════════════════════════════════════════════
@app.get("/api/alerts")
async def get_alerts():
    return [
        {"id": "a1", "type": "critical", "message": "Edge-ring spike: 9 defects in last 10 wafers", "time": "2m ago", "dismissed": False},
        {"id": "a2", "type": "warning",  "message": "Scratch defects increased 30% — Batch B1024",  "time": "14m ago","dismissed": False},
        {"id": "a3", "type": "info",     "message": "Model v2.4 deployed successfully",              "time": "1h ago", "dismissed": False},
        {"id": "a4", "type": "warning",  "message": "Deposition chamber pressure anomaly detected",  "time": "2h ago", "dismissed": False},
    ]

@app.patch("/api/alerts/{alert_id}/dismiss")
async def dismiss_alert(alert_id: str):
    # TODO: update DB record
    return {"id": alert_id, "dismissed": True}


# ════════════════════════════════════════════════════════════════
# GET /api/model-metrics
# Called by: pages/ModelPerformance.jsx → useModelMetrics
# ════════════════════════════════════════════════════════════════
@app.get("/api/model-metrics")
async def get_model_metrics():
    return {
        "accuracy":  94.2,
        "precision": 91.8,
        "recall":    93.5,
        "f1_score":  92.6,
        "auc_roc":   97.1,
        "per_class": [
            {"subject": "Edge-ring", "value": 92},
            {"subject": "Scratch",   "value": 87},
            {"subject": "Center",    "value": 95},
            {"subject": "Random",    "value": 83},
            {"subject": "Donut",     "value": 89},
        ],
    }

@app.get("/api/model-metrics/confusion-matrix")
async def get_confusion_matrix():
    return {
        "labels": ["Edge", "Scratch", "Center", "Clean"],
        "matrix": [
            [142,   8,  3,  1],
            [  5,  98,  2,  0],
            [  4,   3, 71,  1],
            [  0,   1,  0, 210],
        ],
    }

@app.get("/api/model-versions")
async def get_model_versions():
    return [
        {"version": "v2.4", "deployed": "Mar 4, 2026", "accuracy": 94.2, "notes": "Edge-ring recall improved", "is_active": True},
        {"version": "v2.3", "deployed": "Feb 18, 2026","accuracy": 92.8, "notes": "Added random defect class",  "is_active": False},
        {"version": "v2.2", "deployed": "Jan 30, 2026","accuracy": 91.4, "notes": "Grad-CAM integration",       "is_active": False},
        {"version": "v2.1", "deployed": "Jan 12, 2026","accuracy": 89.1, "notes": "Dataset expansion ×3",       "is_active": False},
    ]


# ════════════════════════════════════════════════════════════════
# POST /api/feedback  –  engineer verification (human-in-the-loop)
# Called by: pages/Settings.jsx → waferApi.submitFeedback
# ════════════════════════════════════════════════════════════════
class FeedbackPayload(BaseModel):
    wafer_id:       str
    engineer_label: str
    verified:       bool
    notes:          Optional[str] = ""

@app.post("/api/feedback")
async def submit_feedback(payload: FeedbackPayload):
    # TODO: update WaferInspection record in DB
    # db.query(WaferInspection).filter_by(wafer_id=payload.wafer_id).update({
    #     "engineer_label": payload.engineer_label,
    #     "verified": payload.verified,
    #     "notes": payload.notes,
    # })
    return {"status": "ok", "wafer_id": payload.wafer_id}
