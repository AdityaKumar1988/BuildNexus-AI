/**
 * pages/Upload.jsx
 * ─────────────────────────────────────────────────────────────
 * Wafer image upload & ML inference page.
 *
 * API calls in this file:
 *   POST /api/analyze-wafer  (via useWaferAnalysis hook)
 *
 * Data flow:
 *   1. User drops / selects a wafer image
 *   2. analyze(file) sends FormData to FastAPI backend
 *   3. Backend runs YOLO → bounding_boxes
 *      Backend runs CNN  → defect_type, confidence, severity
 *      Backend generates Grad-CAM → heatmap_url
 *   4. Result stored in hook state and rendered below
 */
import { useCallback, useState } from "react";
import { useWaferAnalysis } from "../hooks/useWaferAnalysis";
import { DetectionViewer } from "../components/wafer";
import { Card, SectionTitle, Badge, KpiCard, btnStyle, btnStyleGhost } from "../components/ui";
import { PageContainer } from "../components/layout";
import { C, DEFECT_COLOR, SEV_COLOR } from "../utils/constants";

export default function Upload() {
  const { analyze, result, phase, progress, error, reset } = useWaferAnalysis();
  const [drag, setDrag] = useState(false);
  const [file, setFile] = useState(null);
  const [preview, setPreview] = useState(null);

  // ── File selection (drag or browse) ───────────────────────
  const onFile = useCallback((f) => {
    if (!f) return;
    setFile(f);
    setPreview(URL.createObjectURL(f));
    reset(); // clear previous result
  }, [reset]);

  const onDrop = (e) => {
    e.preventDefault();
    setDrag(false);
    onFile(e.dataTransfer.files[0]);
  };

  // ── Trigger ML inference ───────────────────────────────────
  // This calls POST /api/analyze-wafer via useWaferAnalysis
  const handleAnalyze = () => {
    if (file) analyze(file);
  };

  const severityColor = { High: "red", Medium: "amber", Low: "green" };

  return (
    <PageContainer
      title="Upload Wafer"
      subtitle={`${new Date().toLocaleString()} · Fab-3 Line A`}
      actions={
        <>
          <button style={btnStyleGhost()}>↓ Export</button>
          <button style={btnStyle(C.green)} onClick={reset} disabled={phase === "idle"}>Reset</button>
        </>
      }
    >
      <div style={{ display: "grid", gap: 16 }}>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>

          {/* ── Upload panel ───────────────────────────────── */}
          <Card>
            <SectionTitle>Wafer Image Upload</SectionTitle>

            <div
              onDragOver={(e) => { e.preventDefault(); setDrag(true); }}
              onDragLeave={() => setDrag(false)}
              onDrop={onDrop}
              style={{
                border: `2px dashed ${drag ? C.green : C.border}`,
                borderRadius: 10, padding: "40px 20px", textAlign: "center",
                background: drag ? "rgba(0,255,157,0.04)" : C.panelAlt,
                transition: "all 0.2s", cursor: "pointer",
              }}
            >
              {preview ? (
                <img src={preview} alt="wafer preview"
                  style={{ maxHeight: 160, maxWidth: "100%", objectFit: "contain", borderRadius: 6 }} />
              ) : (
                <>
                  <div style={{ fontSize: 36, marginBottom: 10, opacity: 0.5 }}>⬡</div>
                  <div style={{ color: C.textMid, fontSize: 14 }}>Drag & drop wafer image here</div>
                  <div style={{ color: C.textDim, fontSize: 12, margin: "6px 0" }}>or</div>
                  <label style={{ ...btnStyle(C.blue), display: "inline-block", cursor: "pointer" }}>
                    Browse Files
                    <input type="file" accept="image/*,.tiff" hidden onChange={(e) => onFile(e.target.files[0])} />
                  </label>
                  <div style={{ color: C.textDim, fontSize: 11, marginTop: 10 }}>PNG · JPG · TIFF · max 50 MB</div>
                </>
              )}
            </div>

            {/* Analyze button */}
            <div style={{ marginTop: 16, display: "flex", gap: 10 }}>
              <button
                onClick={handleAnalyze}
                disabled={!file || phase === "uploading" || phase === "analyzing"}
                style={{ ...btnStyle(C.green), flex: 1, opacity: (!file || phase === "uploading" || phase === "analyzing") ? 0.5 : 1 }}
              >
                {phase === "uploading"  ? `Uploading… ${progress}%`  :
                 phase === "analyzing"  ? "Running inference…"        :
                 "▶  Analyze Wafer"}
              </button>
            </div>

            {/* Progress bar */}
            {(phase === "uploading" || phase === "analyzing") && (
              <div style={{ marginTop: 14 }}>
                <div style={{ color: C.textDim, fontSize: 11, marginBottom: 6 }}>
                  {phase === "uploading" ? "Sending image to inference server…" : "YOLO + CNN + Grad-CAM running…"}
                </div>
                {/* Progress bar */}
                <div style={{ height: 4, background: C.panelAlt, borderRadius: 4, overflow: "hidden" }}>
                  <div style={{
                    height: "100%", width: `${progress}%`,
                    background: `linear-gradient(90deg, ${C.green}, ${C.blue})`,
                    borderRadius: 4, transition: "width 0.4s",
                  }} />
                </div>
              </div>
            )}

            {/* Error state */}
            {phase === "error" && error && (
              <div style={{ marginTop: 12, padding: "10px 14px", background: "rgba(239,68,68,0.1)", border: `1px solid ${C.red}`, borderRadius: 8, color: C.red, fontSize: 13 }}>
                ▲ {error}
              </div>
            )}
          </Card>

          {/* ── Detection viewer ────────────────────────────── */}
          <Card>
            <SectionTitle>Analysis Result</SectionTitle>
            {phase === "done" && result ? (
              // DetectionViewer renders WaferMap + HeatmapOverlay
              // and uses result.bounding_boxes + result.heatmap_url from the API
              <DetectionViewer result={result} />
            ) : (
              <div style={{ display: "flex", alignItems: "center", justifyContent: "center", height: 260, color: C.textDim, fontSize: 13 }}>
                {phase === "uploading" || phase === "analyzing"
                  ? "⟳  Model inference in progress…"
                  : "Upload a wafer image and click Analyze"}
              </div>
            )}
          </Card>
        </div>

        {/* ── Prediction result cards ─────────────────────────
            These values come directly from POST /api/analyze-wafer
            Fields: defect_type, confidence, severity, processed_at  */}
        {phase === "done" && result && (
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr) 2fr", gap: 12 }}>
            <KpiCard
              label="Primary Defect"
              value={result.defect_type}
              color={DEFECT_COLOR[result.defect_type] ? severityColor[DEFECT_COLOR[result.defect_type]] : "red"}
              icon="◉"
            />
            <KpiCard
              label="Confidence"
              value={`${(result.confidence * 100).toFixed(1)}%`}
              color="green"
              icon="◈"
            />
            <KpiCard
              label="Severity"
              value={result.severity}
              color={severityColor[result.severity] ?? "amber"}
              icon="△"
            />

            {/* AI Insights card */}
            <Card>
              <SectionTitle>AI Insights</SectionTitle>
              <p style={{ color: C.textMid, fontSize: 13, lineHeight: 1.6, margin: 0 }}>
                {/* In production, this text comes from a dedicated /api/insights endpoint
                    or is included in the analyze-wafer response as an `insights` field */}
                <span style={{ color: C.amber }}>{result.defect_type}</span> defect detected with{" "}
                {(result.confidence * 100).toFixed(0)}% confidence.
                Severity classified as <span style={{ color: SEV_COLOR[result.severity] }}>{result.severity}</span>.
              </p>
              <div style={{ marginTop: 10, display: "flex", gap: 8, flexWrap: "wrap" }}>
                <Badge color="amber">Inspect edge module</Badge>
                <Badge color="blue">Check alignment</Badge>
              </div>
            </Card>
          </div>
        )}
      </div>
    </PageContainer>
  );
}
