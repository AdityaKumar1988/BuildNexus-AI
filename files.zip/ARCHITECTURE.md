# WaferVision AI — Refactored Architecture

## Project Structure

```
wafervision/
├── backend/
│   └── main.py                     ← FastAPI server (all endpoints)
│
└── src/
    ├── main.jsx                    ← React entry point
    ├── App.jsx                     ← Root: layout + page routing + global alert count
    │
    ├── utils/
    │   └── constants.js            ← Colours, nav items, defect types (single source of truth)
    │
    ├── services/                   ← ALL network calls live here, nowhere else
    │   ├── api.js                  ← Axios instance, base URL, auth interceptor
    │   ├── waferApi.js             ← analyzeWafer · fetchHistory · submitFeedback · analyzeBatch
    │   ├── analyticsApi.js         ← fetchKpis · fetchAnalytics · fetchAlerts · dismissAlert
    │   └── modelApi.js             ← fetchModelMetrics · fetchConfusionMatrix · fetchModelVersions
    │
    ├── hooks/                      ← React hooks that wrap services + manage state
    │   ├── useWaferAnalysis.js     ← upload lifecycle (idle→uploading→analyzing→done|error)
    │   └── useAnalytics.js         ← useAnalytics · useModelMetrics · useHistory
    │
    ├── components/
    │   ├── layout/
    │   │   ├── index.jsx           ← Header · Sidebar · PageContainer
    │   ├── ui/
    │   │   └── index.jsx           ← Card · Badge · KpiCard · SectionTitle · btnStyle helpers
    │   └── wafer/
    │       └── index.jsx           ← WaferMap · HeatmapOverlay · DetectionViewer
    │
    └── pages/                      ← One file per route
        ├── Dashboard.jsx           ← GET /api/analytics/kpis + /api/analytics + /api/alerts
        ├── Upload.jsx              ← POST /api/analyze-wafer
        ├── HistoryAndModel.jsx     ← GET /api/history  +  GET /api/model-metrics
        └── [BatchAnalysis, Analytics, Alerts, Settings …]
```

---

## API → UI Data Flow

```
FastAPI backend                         React frontend
──────────────────────────────────────────────────────────────────
POST /api/analyze-wafer    ←──────── Upload.jsx
  returns: defect_type,               useWaferAnalysis hook
           confidence,                waferApi.analyzeWafer()
           severity,
           bounding_boxes,   ──────►  DetectionViewer (WaferMap + HeatmapOverlay)
           heatmap_url                KpiCard row (defect, confidence, severity)

GET  /api/analytics/kpis   ←──────── Dashboard.jsx
GET  /api/analytics        ←──────── useAnalytics hook
GET  /api/alerts           ←──────── analyticsApi.fetchKpis/fetchAnalytics/fetchAlerts()
  returns: kpis,             ──────►  KpiCard ×4
           defect_distribution ─────► PieChart
           trend ───────────────────► AreaChart
           yield_by_batch ──────────► BarChart
           alerts ──────────────────► Alert feed + Header badge

GET  /api/history          ←──────── History.jsx
  returns: items[],          ──────►  Table rows
           total, page               Pagination controls

GET  /api/model-metrics    ←──────── ModelPerformance.jsx
GET  /api/model-metrics/   ←──────── useModelMetrics hook
       confusion-matrix              modelApi.fetchModelMetrics()
GET  /api/model-versions             modelApi.fetchConfusionMatrix()
  returns: accuracy,         ──────►  Metric cards
           per_class          ──────►  RadarChart
           matrix             ──────►  Confusion matrix table
           versions           ──────►  Version history list

POST /api/feedback         ←──────── Settings.jsx
  payload: wafer_id,                 waferApi.submitFeedback()
           engineer_label,
           verified, notes
```

---

## Adding a New Page (checklist)

1. Add endpoint to `backend/main.py`
2. Add fetch function to the appropriate `src/services/*.js`
3. Add or extend a hook in `src/hooks/`
4. Create `src/pages/MyPage.jsx` — import the hook, render data
5. Add to `PAGE_MAP` in `App.jsx`
6. Add to `NAV_ITEMS` in `utils/constants.js`

---

## Environment Variables

```
# .env.local  (never commit this file)
VITE_API_BASE_URL=http://localhost:8000
```

Set `VITE_API_BASE_URL` to your production FastAPI URL when deploying.

---

## Running Locally

```bash
# Backend
cd backend
pip install fastapi uvicorn python-multipart
uvicorn main:app --reload --port 8000

# Frontend
cd ..
npm install
npm run dev        # → http://localhost:5173
```
