/**
 * services/waferApi.js
 * ─────────────────────────────────────────────────────────────
 * All calls related to individual wafer upload & inspection.
 *
 * Backend endpoints consumed:
 *   POST /api/analyze-wafer   → run ML inference on one image
 *   GET  /api/history         → past inspection records
 *   GET  /api/history/:id     → single wafer detail
 *   POST /api/feedback        → engineer verification
 */
import api from "./api";

/**
 * analyzeWafer
 * Sends a wafer image to the YOLO+CNN inference pipeline.
 *
 * @param {File}     imageFile   - Raw File object from <input> or drag-drop
 * @param {Function} onProgress  - Optional (0-100) progress callback
 *
 * @returns {Promise<{
 *   wafer_id:      string,
 *   defect_type:   string,
 *   confidence:    number,        // 0-1
 *   severity:      "Low"|"Medium"|"High",
 *   bounding_boxes: Array<{x:number,y:number,w:number,h:number,label:string,confidence:number}>,
 *   heatmap_url:   string,        // presigned S3 URL or /static/... path
 *   processed_at:  string,        // ISO timestamp
 * }>}
 */
export async function analyzeWafer(imageFile, onProgress) {
  const formData = new FormData();
  formData.append("file", imageFile);

  const response = await api.post("/api/analyze-wafer", formData, {
    headers: { "Content-Type": "multipart/form-data" },
    onUploadProgress: onProgress
      ? (e) => onProgress(Math.round((e.loaded * 100) / e.total))
      : undefined,
  });

  return response;
}

/**
 * fetchHistory
 * Returns paginated inspection records for the History table.
 *
 * @param {{ page?:number, limit?:number, defect_type?:string, search?:string }} params
 *
 * @returns {Promise<{
 *   items: Array<{
 *     wafer_id:    string,
 *     timestamp:   string,
 *     defect_type: string,
 *     confidence:  number,
 *     severity:    string,
 *     verified:    boolean,
 *     engineer:    string|null,
 *   }>,
 *   total: number,
 *   page:  number,
 *   pages: number,
 * }>}
 */
export async function fetchHistory(params = {}) {
  return api.get("/api/history", { params });
}

/**
 * fetchWaferDetail
 * Full inspection record for the Wafer Detail page.
 */
export async function fetchWaferDetail(waferId) {
  return api.get(`/api/history/${waferId}`);
}

/**
 * submitFeedback
 * Human-in-the-loop: engineer verifies / overrides AI label.
 *
 * @param {{ wafer_id:string, engineer_label:string, verified:boolean, notes:string }} payload
 */
export async function submitFeedback(payload) {
  return api.post("/api/feedback", payload);
}

/**
 * fetchBatches  –  GET /api/batches
 * Returns list of batch jobs with aggregate stats.
 */
export async function fetchBatches(params = {}) {
  return api.get("/api/batches", { params });
}

/**
 * analyzeBatch  –  POST /api/analyze-batch
 * Uploads multiple files for batch inference.
 *
 * @param {FileList|File[]} files
 */
export async function analyzeBatch(files, onProgress) {
  const formData = new FormData();
  Array.from(files).forEach((f) => formData.append("files", f));

  return api.post("/api/analyze-batch", formData, {
    headers: { "Content-Type": "multipart/form-data" },
    onUploadProgress: onProgress
      ? (e) => onProgress(Math.round((e.loaded * 100) / e.total))
      : undefined,
  });
}
